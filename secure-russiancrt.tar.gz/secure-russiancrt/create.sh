#!/bin/bash

clear

# ============================================================
# Безопасный CA Минцифры посредством nameConstraints
#
# ВАЖНО:
#   Скрипт НИЧЕГО не устанавливает в системное хранилище.
# ============================================================

# ------------------------------------------------------------
# Настройки
# ------------------------------------------------------------

SOURCE_CA="./russian_trusted_root_ca_pem.crt"
WORKDIR="./mincifra-constrained"

CONSTRAINT_CA="$WORKDIR/russian_secured_private_root_ca.crt"
CONSTRAINT_KEY="$WORKDIR/russian_secured_private_root_ca.key"

OUTPUT_CA="$WORKDIR/russian_constrained_intermediate_ca.crt"

SOURCE_PUBKEY="$WORKDIR/russian_source.pub"

CSR="$WORKDIR/russian_new_root_ca.csr"
CSR_KEY="$WORKDIR/russian-dummy-csr.key"

# ROOT_EXT="$WORKDIR/russian-root-extensions.conf"
CA_EXT="$WORKDIR/russian-ca-extensions.conf"

# ------------------------------------------------------------
# Скачать свежий сертификат
# ------------------------------------------------------------

command -v curl >/dev/null 2>&1 || { echo "ERROR: curl не установлен."; exit 1; }

rm -f "$SOURCE_CA"

# Скачать корневой сертификат (с перезаписью)
curl -o "$SOURCE_CA" https://gu-st.ru/content/lending/$SOURCE_CA

if [ ! -f "$SOURCE_CA" ]; then
    echo "ERROR: файл сертификата "$SOURCE_CA" не обнаружен."
    exit 1
fi

# ------------------------------------------------------------
# Проверки
# ------------------------------------------------------------

if ! command -v openssl >/dev/null 2>&1; then
    echo "ERROR: openssl не найден."
    exit 1
fi

if [[ ! -f "$SOURCE_CA" ]]; then
    echo "ERROR: исходный сертификат не найден:"
    echo "       $SOURCE_CA"
    exit 1
fi

mkdir -p "$WORKDIR"

echo
echo "============================================================"
echo " Исходный сертификат"
echo "============================================================"
echo

openssl x509 \
    -in "$SOURCE_CA" \
    -noout \
    -subject \
    -issuer \
    -serial \
    -fingerprint -sha256

echo

if ! openssl x509 \
        -in "$SOURCE_CA" \
        -text \
        -noout |
        grep -q 'CA:TRUE'; then

    echo "ERROR: исходный сертификат не является CA."
    exit 1
fi

# ------------------------------------------------------------
# Получаем Subject исходного сертификата
#
# RFC2253 даёт:
#
#   CN=Russian Trusted Root CA,O=...,C=RU
#
# -subj OpenSSL хочет:
#
#   /C=RU/O=.../CN=Russian Trusted Root CA
#
# Здесь используется обычный DN без запятых внутри значений,
# что соответствует сертификату Минцифры из нашего случая.
# ------------------------------------------------------------

echo
echo "=== Получаем Subject исходного CA ==="

SOURCE_SUBJECT="$(
    openssl x509 \
        -in "$SOURCE_CA" \
        -noout \
        -subject \
        -nameopt RFC2253 |
    sed 's/^subject=//'
)"

echo
echo "RFC2253:"
echo "  $SOURCE_SUBJECT"

# RFC2253 идёт от CN к C, а -subj удобнее задавать от C к CN.
SUBJ="$(
    printf '%s\n' "$SOURCE_SUBJECT" |
    awk -F',' '
    {
        for (i = NF; i >= 1; i--) {
            gsub(/^[[:space:]]+|[[:space:]]+$/, "", $i)
            printf "/%s", $i
        }
        printf "\n"
    }'
)"

echo
echo "Subject для -subj:"
echo "  $SUBJ"

echo
echo "============================================================"
echo " Создаём Доверенный сертификат"
echo "============================================================"
echo

    openssl req \
        -x509 \
        -newkey rsa:4096 \
        -nodes \
        -days 3650 \
        -keyout "$CONSTRAINT_KEY" \
        -out "$CONSTRAINT_CA" \
        -subj "/CN=Secured-Private-Root" \
        -addext "basicConstraints = critical,CA:true,pathlen:5" \
        -addext "keyUsage = critical,digitalSignature,keyCertSign,cRLSign"
#        -addext "nameConstraints = critical,permitted;DNS:ru,permitted;DNS:su,permitted;DNS:xn--p1ai"

    chmod 600 "$CONSTRAINT_KEY"
    chmod 644 "$CONSTRAINT_CA"

echo

# ------------------------------------------------------------
# Извлекаем публичный ключ исходного CA
# ------------------------------------------------------------

echo
echo "=== Извлекаем публичный ключ исходного CA ==="

openssl x509 \
    -in "$SOURCE_CA" \
    -pubkey \
    -noout \
    > "$SOURCE_PUBKEY"

# ------------------------------------------------------------
# Создаём временный CSR.
#
# Ключ CSR здесь НЕ имеет значения.
# В новый сертификат ниже будет принудительно вставлен
# публичный ключ исходного CA через -force_pubkey.
# ------------------------------------------------------------

echo
echo "=== Создаём временный CSR ==="

openssl req \
    -new \
    -newkey rsa:2048 \
    -nodes \
    -keyout "$CSR_KEY" \
    -out "$CSR" \
    -subj "$SUBJ"

# ------------------------------------------------------------
# Файл расширений нового CA (ограничения ru, su, рф)
# ------------------------------------------------------------

cat > "$CA_EXT" <<'EOF'
[ constrained_ca ]

subjectKeyIdentifier = hash
authorityKeyIdentifier = keyid:always,issuer

basicConstraints = critical,CA:true

keyUsage = critical,digitalSignature,keyCertSign,cRLSign
nameConstraints = critical,permitted;DNS:.ru,permitted;DNS:.su,permitted;DNS:.xn--p1ai
EOF

echo
echo "============================================================"
echo " Создаём Промежуточный сертификат"
echo "============================================================"
echo

openssl x509 \
    -req \
    -in "$CSR" \
    -CA "$CONSTRAINT_CA" \
    -CAkey "$CONSTRAINT_KEY" \
    -CAcreateserial \
    -days 3650 \
    -sha256 \
    -force_pubkey "$SOURCE_PUBKEY" \
    -out "$OUTPUT_CA" \
    -extfile "$CA_EXT" \
    -extensions constrained_ca

chmod 644 "$OUTPUT_CA"

# ------------------------------------------------------------
# Проверяем новый сертификат
# ------------------------------------------------------------

echo
echo "============================================================"
echo " Промежуточный сертификат"
echo "============================================================"
echo

openssl x509 \
    -in "$OUTPUT_CA" \
    -noout \
    -subject \
    -issuer \
    -serial \
    -fingerprint -sha256

echo
echo "=== Extensions ==="

openssl x509 \
    -in "$OUTPUT_CA" \
    -text \
    -noout |
grep -A8 -E "Basic Constraints|Key Usage|Name Constraints"

# ------------------------------------------------------------
# Проверяем совпадение публичных ключей
# ------------------------------------------------------------

echo
echo "============================================================"
echo " Проверяем публичный ключ"
echo "============================================================"
echo

ORIGINAL_HASH="$(
    openssl x509 \
        -in "$SOURCE_CA" \
        -pubkey \
        -noout |
    openssl pkey \
        -pubin \
        -outform DER |
    sha256sum |
    awk '{print $1}'
)"

NEW_HASH="$(
    openssl x509 \
        -in "$OUTPUT_CA" \
        -pubkey \
        -noout |
    openssl pkey \
        -pubin \
        -outform DER |
    sha256sum |
    awk '{print $1}'
)"

echo "Исходный CA: $ORIGINAL_HASH"
echo "Новый CA:    $NEW_HASH"

if [[ "$ORIGINAL_HASH" != "$NEW_HASH" ]]; then
    echo
    echo "ERROR: публичные ключи НЕ совпадают."
    exit 1
fi

echo
echo "OK: публичный ключ исходного CA сохранён."

echo
echo "============================================================"
echo " Проверяем цепочку нового CA"
echo "============================================================"
echo

openssl verify \
    -CAfile "$CONSTRAINT_CA" \
    "$OUTPUT_CA"

echo

# Создаём архив сертификатов для установки
tar -czf secure-certs.tar.gz "$CONSTRAINT_CA" "$OUTPUT_CA"

# ------------------------------------------------------------
# Финальный вывод
# ------------------------------------------------------------

echo
echo "============================================================"
echo " ГОТОВО"
echo "============================================================"
echo
echo "Исходный CA:"
echo "  $SOURCE_CA"
echo
echo "Доверенный сертификат:"
echo "  $CONSTRAINT_CA"
echo
echo "Промежуточный сертификат:"
echo "  $OUTPUT_CA"
echo
echo "Разрешённые зоны:"
echo "  .ru"
echo "  .su"
echo "  .xn--p1ai"
echo
echo "В системное хранилище ничего не устанавливалось."
echo "Собран архив ./secure-certs.tar.gz с нужными сертификатами."
echo
echo "Хранилище в Mageia: /usr/share/pki/ca-trust-source/anchors/"
echo "После установки сертификатов обновите хранилище: update-ca-trust"
echo
echo "Хранилище в Ubuntu: /usr/local/share/ca-certificates/"
echo "После установки сертификатов обновите хранилище: update-ca-certificates"
echo "============================================================"

echo
read -n 1 -s -p "Нажмите любую клавишу для выхода..."
