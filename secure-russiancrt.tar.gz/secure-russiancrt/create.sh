#!/usr/bin/env bash
set -euo pipefail

# ============================================================
# "Обезжиривание" CA Минцифры посредством nameConstraints
#
# Создаёт:
#
#   Secured-Private-Root.crt
#       |
#       +-- new_root_ca.crt
#             |
#             +-- (в реальной жизни) сертификаты сайтов,
#                 подписанные исходным приватным ключом CA
#
# Secured-Private-Root разрешает только:
#
#   .ru
#   .su
#   .xn--p1ai   (.рф)
#
# ВАЖНО:
#   Скрипт НИЧЕГО не устанавливает в системное хранилище.
# ============================================================

umask 077

command -v curl >/dev/null 2>&1 || { echo "Ошибка: curl не установлен."; exit 1; }

# Скачать корневой сертификат (с перезаписью)
curl -o ./russian_trusted_root_ca_pem.crt https://gu-st.ru/content/lending/russian_trusted_root_ca_pem.crt

# ------------------------------------------------------------
# Настройки
# ------------------------------------------------------------

SOURCE_CA="${1:-russian_trusted_root_ca_pem.crt}"
WORKDIR="${2:-./mincifra-constrained}"

CONSTRAINT_CA="$WORKDIR/Russian-Secured-Private-Root.crt"
CONSTRAINT_KEY="$WORKDIR/Russian-Secured-Private-Root.key"

OUTPUT_CA="$WORKDIR/russian_new_root_ca.crt"

SOURCE_PUBKEY="$WORKDIR/russian_source.pub"

CSR="$WORKDIR/russian_new_root_ca.csr"
CSR_KEY="$WORKDIR/russian-dummy-csr.key"

ROOT_EXT="$WORKDIR/russian-root-extensions.conf"
CA_EXT="$WORKDIR/russian-ca-extensions.conf"

# Тестовая цепочка
TEST_CA_KEY="$WORKDIR/test-intermediate.key"
TEST_CA_CSR="$WORKDIR/test-intermediate.csr"
TEST_CA_CERT="$WORKDIR/test-intermediate.crt"

TEST_RU_KEY="$WORKDIR/test-ru.key"
TEST_RU_CSR="$WORKDIR/test-ru.csr"
TEST_RU_CERT="$WORKDIR/test-ru.crt"

TEST_COM_KEY="$WORKDIR/test-com.key"
TEST_COM_CSR="$WORKDIR/test-com.csr"
TEST_COM_CERT="$WORKDIR/test-com.crt"

# ------------------------------------------------------------
# Проверки
# ------------------------------------------------------------

if ! command -v openssl >/dev/null 2>&1; then
    echo "ERROR: openssl не найден."
    exit 1
fi

if [[ ! -f "$SOURCE_CA" ]]; then
    echo "ERROR: исходный сертификат не найден:"
    echo "       $SOURCE_CA"
    exit 1
fi

mkdir -p "$WORKDIR"

echo
echo "============================================================"
echo " Исходный сертификат"
echo "============================================================"
echo

openssl x509 \
    -in "$SOURCE_CA" \
    -noout \
    -subject \
    -issuer \
    -serial \
    -fingerprint -sha256

echo

if ! openssl x509 \
        -in "$SOURCE_CA" \
        -text \
        -noout |
        grep -q 'CA:TRUE'; then

    echo "ERROR: исходный сертификат не является CA."
    exit 1
fi

# ------------------------------------------------------------
# Получаем Subject исходного сертификата
#
# RFC2253 даёт:
#
#   CN=Russian Trusted Root CA,O=...,C=RU
#
# -subj OpenSSL хочет:
#
#   /C=RU/O=.../CN=Russian Trusted Root CA
#
# Здесь используется обычный DN без запятых внутри значений,
# что соответствует сертификату Минцифры из нашего случая.
# ------------------------------------------------------------

echo
echo "=== Получаем Subject исходного CA ==="

SOURCE_SUBJECT="$(
    openssl x509 \
        -in "$SOURCE_CA" \
        -noout \
        -subject \
        -nameopt RFC2253 |
    sed 's/^subject=//'
)"

echo
echo "RFC2253:"
echo "  $SOURCE_SUBJECT"

# RFC2253 идёт от CN к C, а -subj удобнее задавать от C к CN.
SUBJ="$(
    printf '%s\n' "$SOURCE_SUBJECT" |
    awk -F',' '
    {
        for (i = NF; i >= 1; i--) {
            gsub(/^[[:space:]]+|[[:space:]]+$/, "", $i)
            printf "/%s", $i
        }
        printf "\n"
    }'
)"

echo
echo "Subject для -subj:"
echo "  $SUBJ"

# ------------------------------------------------------------
# Создаём ограничивающий Root CA
# ------------------------------------------------------------

if [[ -f "$CONSTRAINT_CA" && -f "$CONSTRAINT_KEY" ]]; then

    echo
    echo "============================================================"
    echo " Secured-Private-Root уже существует"
    echo "============================================================"

else

    echo
    echo "============================================================"
    echo " Создаём Secured-Private-Root"
    echo "============================================================"

    openssl req \
        -x509 \
        -newkey rsa:4096 \
        -nodes \
        -days 3650 \
        -keyout "$CONSTRAINT_KEY" \
        -out "$CONSTRAINT_CA" \
        -subj "/CN=Secured-Private-Root" \
        -addext "basicConstraints = critical,CA:true,pathlen:5" \
        -addext "keyUsage = critical,digitalSignature,keyCertSign,cRLSign" \
        -addext "nameConstraints = critical,permitted;DNS:.ru,permitted;DNS:.su,permitted;DNS:.xn--p1ai"

    chmod 600 "$CONSTRAINT_KEY"
    chmod 644 "$CONSTRAINT_CA"
fi

# ------------------------------------------------------------
# Показываем ограничения
# ------------------------------------------------------------

echo
echo "============================================================"
echo " Name Constraints"
echo "============================================================"
echo

openssl x509 \
    -in "$CONSTRAINT_CA" \
    -text \
    -noout |
grep -A8 "Name Constraints"

# ------------------------------------------------------------
# Извлекаем публичный ключ исходного CA
# ------------------------------------------------------------

echo
echo "=== Извлекаем публичный ключ исходного CA ==="

openssl x509 \
    -in "$SOURCE_CA" \
    -pubkey \
    -noout \
    > "$SOURCE_PUBKEY"

# ------------------------------------------------------------
# Создаём временный CSR.
#
# Ключ CSR здесь НЕ имеет значения.
# В новый сертификат ниже будет принудительно вставлен
# публичный ключ исходного CA через -force_pubkey.
# ------------------------------------------------------------

echo
echo "=== Создаём временный CSR ==="

openssl req \
    -new \
    -newkey rsa:2048 \
    -nodes \
    -keyout "$CSR_KEY" \
    -out "$CSR" \
    -subj "$SUBJ"

# ------------------------------------------------------------
# Расширения нового CA
# ------------------------------------------------------------

cat > "$CA_EXT" <<'EOF'
[ constrained_ca ]

subjectKeyIdentifier = hash
authorityKeyIdentifier = keyid:always,issuer

basicConstraints = critical,CA:true

keyUsage = critical,digitalSignature,keyCertSign,cRLSign
EOF

# ------------------------------------------------------------
# Создаём "обезжиренный" сертификат
# ------------------------------------------------------------

echo
echo "============================================================"
echo " Создаём ограниченный сертификат"
echo "============================================================"
echo

openssl x509 \
    -req \
    -in "$CSR" \
    -CA "$CONSTRAINT_CA" \
    -CAkey "$CONSTRAINT_KEY" \
    -CAcreateserial \
    -days 3650 \
    -sha256 \
    -force_pubkey "$SOURCE_PUBKEY" \
    -out "$OUTPUT_CA" \
    -extfile "$CA_EXT" \
    -extensions constrained_ca

chmod 644 "$OUTPUT_CA"

# ------------------------------------------------------------
# Проверяем новый сертификат
# ------------------------------------------------------------

echo
echo "============================================================"
echo " Новый сертификат"
echo "============================================================"
echo

openssl x509 \
    -in "$OUTPUT_CA" \
    -noout \
    -subject \
    -issuer \
    -serial \
    -fingerprint -sha256

echo
echo "=== Extensions ==="

openssl x509 \
    -in "$OUTPUT_CA" \
    -text \
    -noout |
grep -A8 -E "Basic Constraints|Key Usage"

# ------------------------------------------------------------
# Проверяем совпадение публичных ключей
# ------------------------------------------------------------

echo
echo "============================================================"
echo " Проверяем публичный ключ"
echo "============================================================"
echo

ORIGINAL_HASH="$(
    openssl x509 \
        -in "$SOURCE_CA" \
        -pubkey \
        -noout |
    openssl pkey \
        -pubin \
        -outform DER |
    sha256sum |
    awk '{print $1}'
)"

NEW_HASH="$(
    openssl x509 \
        -in "$OUTPUT_CA" \
        -pubkey \
        -noout |
    openssl pkey \
        -pubin \
        -outform DER |
    sha256sum |
    awk '{print $1}'
)"

echo "Исходный CA: $ORIGINAL_HASH"
echo "Новый CA:    $NEW_HASH"

if [[ "$ORIGINAL_HASH" != "$NEW_HASH" ]]; then
    echo
    echo "ERROR: публичные ключи НЕ совпадают."
    exit 1
fi

echo
echo "OK: публичный ключ исходного CA сохранён."

# ------------------------------------------------------------
# Проверяем цепочку:
#
# Secured-Private-Root
#          |
#          +-- new_root_ca
#
# ------------------------------------------------------------

echo
echo "============================================================"
echo " Проверяем цепочку нового CA"
echo "============================================================"
echo

openssl verify \
    -CAfile "$CONSTRAINT_CA" \
    "$OUTPUT_CA"

echo
echo "OK: new_root_ca доверен через Secured-Private-Root."

# ============================================================
# ТЕСТ NAME CONSTRAINTS
#
# Здесь создаётся отдельный тестовый intermediate CA,
# подписанный Secured-Private-Root.
#
# Это НЕ тестирует приватный ключ Минцифры.
# Он нам недоступен и для теста не нужен.
#
# Зато проверяется именно механизм nameConstraints.
# ============================================================

echo
echo "============================================================"
echo " Тестируем nameConstraints"
echo "============================================================"

# ------------------------------------------------------------
# Extensions тестовой intermediate CA
# ------------------------------------------------------------

cat > "$ROOT_EXT" <<'EOF'
[ test_ca ]

basicConstraints = critical,CA:true,pathlen:0

keyUsage = critical,digitalSignature,keyCertSign,cRLSign

subjectKeyIdentifier = hash
authorityKeyIdentifier = keyid,issuer
EOF

# ------------------------------------------------------------
# Тестовая intermediate CA
# ------------------------------------------------------------

echo
echo "=== Создаём тестовый intermediate CA ==="

openssl req \
    -new \
    -newkey rsa:2048 \
    -nodes \
    -keyout "$TEST_CA_KEY" \
    -out "$TEST_CA_CSR" \
    -subj "/CN=NameConstraints-Test-CA"

openssl x509 \
    -req \
    -in "$TEST_CA_CSR" \
    -CA "$CONSTRAINT_CA" \
    -CAkey "$CONSTRAINT_KEY" \
    -CAcreateserial \
    -days 30 \
    -sha256 \
    -out "$TEST_CA_CERT" \
    -extfile "$ROOT_EXT" \
    -extensions test_ca

# ------------------------------------------------------------
# Leaf .ru
# ------------------------------------------------------------

echo
echo "=== Создаём test.example.ru ==="

cat > "$WORKDIR/leaf-ru.ext" <<'EOF'
[ leaf ]

basicConstraints = critical,CA:false

keyUsage = critical,digitalSignature,keyEncipherment

extendedKeyUsage = serverAuth

subjectAltName = DNS:test.example.ru
EOF

openssl req \
    -new \
    -newkey rsa:2048 \
    -nodes \
    -keyout "$TEST_RU_KEY" \
    -out "$TEST_RU_CSR" \
    -subj "/CN=test.example.ru"

openssl x509 \
    -req \
    -in "$TEST_RU_CSR" \
    -CA "$TEST_CA_CERT" \
    -CAkey "$TEST_CA_KEY" \
    -CAcreateserial \
    -days 30 \
    -sha256 \
    -out "$TEST_RU_CERT" \
    -extfile "$WORKDIR/leaf-ru.ext" \
    -extensions leaf

# ------------------------------------------------------------
# Проверяем .ru
# ------------------------------------------------------------

echo
echo "=== Проверяем .ru ==="

if openssl verify \
        -CAfile "$CONSTRAINT_CA" \
        -untrusted "$TEST_CA_CERT" \
        "$TEST_RU_CERT"; then

    echo
    echo "OK: .ru разрешён."
else
    echo
    echo "ERROR: .ru был заблокирован."
    exit 1
fi

# ------------------------------------------------------------
# Leaf .com
# ------------------------------------------------------------

echo
echo "=== Создаём test.example.com ==="

cat > "$WORKDIR/leaf-com.ext" <<'EOF'
[ leaf ]

basicConstraints = critical,CA:false

keyUsage = critical,digitalSignature,keyEncipherment

extendedKeyUsage = serverAuth

subjectAltName = DNS:test.example.com
EOF

openssl req \
    -new \
    -newkey rsa:2048 \
    -nodes \
    -keyout "$TEST_COM_KEY" \
    -out "$TEST_COM_CSR" \
    -subj "/CN=test.example.com"

openssl x509 \
    -req \
    -in "$TEST_COM_CSR" \
    -CA "$TEST_CA_CERT" \
    -CAkey "$TEST_CA_KEY" \
    -CAcreateserial \
    -days 30 \
    -sha256 \
    -out "$TEST_COM_CERT" \
    -extfile "$WORKDIR/leaf-com.ext" \
    -extensions leaf

# ------------------------------------------------------------
# Проверяем .com — он ДОЛЖЕН быть заблокирован
# ------------------------------------------------------------

echo
echo "=== Проверяем .com ==="

if openssl verify \
        -CAfile "$CONSTRAINT_CA" \
        -untrusted "$TEST_CA_CERT" \
        "$TEST_COM_CERT"; then

    echo
    echo "ERROR: .com неожиданно прошёл проверку!"
    exit 1

else

    echo
    echo "OK: .com заблокирован nameConstraints."
fi

# ------------------------------------------------------------
# Финальный вывод
# ------------------------------------------------------------

echo
echo "============================================================"
echo " ГОТОВО"
echo "============================================================"
echo
echo "Исходный CA:"
echo "  $SOURCE_CA"
echo
echo "Ограничивающий Root:"
echo "  $CONSTRAINT_CA"
echo
echo "Ключ ограничивающего Root:"
echo "  $CONSTRAINT_KEY"
echo
echo "Обезжиренный сертификат:"
echo "  $OUTPUT_CA"
echo
echo "Разрешённые зоны:"
echo "  .ru"
echo "  .su"
echo "  .xn--p1ai"
echo
echo "Тест:"
echo "  test.example.ru  -> PASS"
echo "  test.example.com -> BLOCKED"
echo
echo "Ничего не устанавливалось в системное хранилище."
echo
echo "Собран архив ./secure-certs.tar.gz с нужными сертификатами."
echo "Хранилище в Mageia: /usr/share/pki/ca-trust-source/anchors/"
echo "После установки сертификатов обновите хранилище: update-ca-trust"
echo "============================================================"

tar -czf secure-certs.tar.gz "$CONSTRAINT_CA" "$OUTPUT_CA"

echo
read -n 1 -s -p "Нажмите любую клавишу для выхода..."
