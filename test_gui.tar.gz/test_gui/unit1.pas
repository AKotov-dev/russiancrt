unit Unit1;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, StdCtrls,
  lclintf, ExtCtrls; // Process,

type

  { TMainForm }

  TMainForm = class(TForm)
    Button1: TButton;
    Image1: TImage;
    Label1: TLabel;
    Label2: TLabel;
    Label3: TLabel;
    Label4: TLabel;
    Label5: TLabel;
    Memo1: TMemo;
    Memo2: TMemo;
    procedure Button1Click(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure FormResize(Sender: TObject);
    procedure FormShow(Sender: TObject);
    procedure Label3Click(Sender: TObject);
    procedure Label3MouseEnter(Sender: TObject);
    procedure Label3MouseLeave(Sender: TObject);
    procedure Label4Click(Sender: TObject);
    procedure Label5Click(Sender: TObject);
  private

  public

  end;

var
  MainForm: TMainForm;

implementation

uses start_openssl;

  {$R *.lfm}

  { TMainForm }

{
//Test
function RunOpenSSL(const Host: string): string;
var
  P: TProcess;
  Output: TStringStream;
begin
  P := TProcess.Create(nil);
  Output := TStringStream.Create('');
  try
    P.Executable := 'bash';

    P.Parameters.Add('-c');
    P.Parameters.Add(
      Format('openssl s_client -connect %s:443 -servername %s ' +
      '-verify_return_error </dev/null 2>&1 | ' +
      'grep -E "depth=|verify error|Verify return code"', [Host, Host])
      );

    P.Options := [poUsePipes];  //  , poWaitOnExit
    P.Execute;

    Output.CopyFrom(P.Output, P.Output.NumBytesAvailable);
    Result := Output.DataString;
  finally
    Output.Free;
    P.Free;
  end;
end;
}

//Start
procedure TMainForm.Button1Click(Sender: TObject);
begin
  Memo1.Clear;
  Memo2.Clear;

  Label1.Font.Style := [];
  Label1.Font.Color := clDefault;

  Label2.Font.Style := [];
  Label2.Font.Color := clDefault;

  //Command
 { Memo1.Text := RunOpenSSL('sberbank.ru');
  Memo2.Text := RunOpenSSL('sberbank.com');
  }

  TOpenSSLThread.Create('sberbank.ru', Memo1);
  TOpenSSLThread.Create('sberbank.com', Memo2);
end;

procedure TMainForm.FormCreate(Sender: TObject);
var
  bmp: TBitmap;
begin
  // Устраняем баг иконки приложения
  bmp := TBitmap.Create;
  try
    bmp.PixelFormat := pf32bit;
    bmp.Assign(Image1.Picture.Graphic);
    Application.Icon.Assign(bmp);
  finally
    bmp.Free;
  end;
end;

procedure TMainForm.FormResize(Sender: TObject);
begin
  Memo1.Height := Memo2.Height;
end;

procedure TMainForm.FormShow(Sender: TObject);
begin
  // Button1.Click;
end;

procedure TMainForm.Label3Click(Sender: TObject);
begin
  OpenURL('https://sberbank.ru');
end;

procedure TMainForm.Label3MouseEnter(Sender: TObject);
begin
  (Sender as TLabel).Font.Color := clRed;
end;

procedure TMainForm.Label3MouseLeave(Sender: TObject);
begin
  (Sender as TLabel).Font.Color := clBlue;
end;

procedure TMainForm.Label4Click(Sender: TObject);
begin
  OpenURL('https://sberbank.com');
end;

//Проверка установки сертификатов Минцифры
procedure TMainForm.Label5Click(Sender: TObject);
begin
  OpenURL('https://www.sberbank.ru/ru/certificates');
end;

end.
