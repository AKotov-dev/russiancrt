unit Unit1;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, StdCtrls, Process, lclintf;

type

  { TForm1 }

  TForm1 = class(TForm)
    Button1: TButton;
    Label1: TLabel;
    Label2: TLabel;
    Label3: TLabel;
    Label4: TLabel;
    Label5: TLabel;
    Memo1: TMemo;
    Memo2: TMemo;
    procedure Button1Click(Sender: TObject);
    procedure Label3Click(Sender: TObject);
    procedure Label3MouseEnter(Sender: TObject);
    procedure Label3MouseLeave(Sender: TObject);
    procedure Label4Click(Sender: TObject);
    procedure Label5Click(Sender: TObject);
  private

  public

  end;

var
  Form1: TForm1;

implementation

{$R *.lfm}

{ TForm1 }

//Test
function RunOpenSSL(const Host: string): string;
var
  P: TProcess;
  Output: TStringStream;
begin
  P := TProcess.Create(nil);
  Output := TStringStream.Create('');
  try
    P.Executable := '/bin/bash';

    P.Parameters.Add('-c');
    P.Parameters.Add(
      Format('openssl s_client -connect %s:443 -servername %s ' +
      '-verify_return_error </dev/null 2>&1 | ' +
      'grep -E "depth=|verify error|Verify return code"', [Host, Host])
      );

    P.Options := [poUsePipes, poWaitOnExit];
    P.Execute;

    Output.CopyFrom(P.Output, P.Output.NumBytesAvailable);
    Result := Output.DataString;
  finally
    Output.Free;
    P.Free;
  end;
end;

//Start
procedure TForm1.Button1Click(Sender: TObject);
begin
  Memo1.Clear;
  Memo2.Clear;

  Label1.Font.Style := [];
  Label1.Font.Color := clDefault;

  Label2.Font.Style := [];
  Label2.Font.Color := clDefault;

  //Command
  Memo1.Text := RunOpenSSL('sberbank.ru');
  Memo2.Text := RunOpenSSL('sberbank.com');

  //Status
  if Pos('violation', Memo1.Text) <> 0 then
  begin
    Label1.Font.Style := [fsBold];
    Label1.Font.Color := clRed;
  end
  else
  begin
    Label1.Font.Style := [fsBold];
    Label1.Font.Color := clGreen;
  end;

  if Pos('violation', Memo2.Text) <> 0 then
  begin
    Label2.Font.Style := [fsBold];
    Label2.Font.Color := clRed;
  end
  else
  begin
    Label2.Font.Style := [fsBold];
    Label2.Font.Color := clGreen;
  end;

end;

procedure TForm1.Label3Click(Sender: TObject);
begin
  OpenURL('https://sberbank.ru');
end;

procedure TForm1.Label3MouseEnter(Sender: TObject);
begin
  (Sender as TLabel).Font.Color := clRed;
end;

procedure TForm1.Label3MouseLeave(Sender: TObject);
begin
  (Sender as TLabel).Font.Color := clBlue;
end;

procedure TForm1.Label4Click(Sender: TObject);
begin
  OpenURL('https://sberbank.com');
end;

//Проверка установки сертификатов Минцифры
procedure TForm1.Label5Click(Sender: TObject);
begin
  OpenURL('https://www.sberbank.ru/ru/certificates');
end;

end.
