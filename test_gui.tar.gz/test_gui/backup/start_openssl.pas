unit start_openssl;

{$mode ObjFPC}{$H+}
interface

uses
  Classes, SysUtils, StdCtrls, Process;

type
  TOpenSSLThread = class(TThread)
  private
    FHost: string;
    FResultText: string;
    FTargetMemo: TMemo; // Ссылка на конкретный Memo для вывода
    procedure SyncShowResult;
  protected
    procedure Execute; override;
  public
    constructor Create(const AHost: string; ATargetMemo: TMemo);
  end;

implementation

uses unit1;

constructor TOpenSSLThread.Create(const AHost: string; ATargetMemo: TMemo);
begin
  inherited Create(False);
  FHost := AHost;
  FTargetMemo := ATargetMemo; // Запоминаем, куда писать ответ
  FreeOnTerminate := True;
end;

procedure TOpenSSLThread.Execute;
var
  P: TProcess;
  OutputStr: TStringStream;
begin
  P := TProcess.Create(nil);
  OutputStr := TStringStream.Create('');
  try
    P.Executable := 'bash';
    P.Parameters.Add('-c');
    P.Parameters.Add(
      Format('openssl s_client -connect %s:443 -servername %s ' +
      '-verify_return_error </dev/null 2>&1 | ' +
      'grep -E "depth=|verify error|Verify return code"', [FHost, FHost])
      );

    P.Options := [poUsePipes, poWaitOnExit, poStderrToOutput];
    P.Execute;

    OutputStr.CopyFrom(P.Output, 0);
    FResultText := OutputStr.DataString;

    if not Terminated then
      Synchronize(@SyncShowResult);
  finally
    OutputStr.Free;
    P.Free;
  end;
end;

procedure TOpenSSLThread.SyncShowResult;
begin
  // Проверяем, существует ли еще форма/Memo (на случай, если программу закрыли раньше времени)
  if Assigned(FTargetMemo) then
    FTargetMemo.Text := FResultText;

  //Status
  with MainForm do
  begin
    if Pos('violation', Memo1.Text) <> 0 then
    begin
      Label1.Font.Style := [fsBold];
      Label1.Font.Color := clRed;
    end
    else
    begin
      Label1.Font.Style := [fsBold];
      Label1.Font.Color := clGreen;
    end;

    if Pos('violation', Memo2.Text) <> 0 then
    begin
      Label2.Font.Style := [fsBold];
      Label2.Font.Color := clRed;
    end
    else
    begin
      Label2.Font.Style := [fsBold];
      Label2.Font.Color := clGreen;
    end;
  end;
end;

end.
